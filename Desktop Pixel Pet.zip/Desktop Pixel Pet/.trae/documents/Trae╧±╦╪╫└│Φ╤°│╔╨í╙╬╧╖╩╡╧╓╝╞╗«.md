## 项目目标与范围

* 构建在 Windows 上本地运行的像素桌宠养成小游戏，离线、轻量、模块化。

* 使用 Tkinter 构建主 GUI（登录/注册/找回、主页、商城），Pygame 负责像素桌宠帧动画与交互渲染，pywin32 实现桌宠悬浮窗（置顶/透明/拖拽/右键菜单）。

* 数据仅存储于 `data/*.json`，运行时间作为唯一“货币”，商城解锁桌宠。

## 技术选型与依赖

* 核心语言：Python 3.8+

* GUI：Tkinter（内置，启动快）、Pygame（动画与交互）、Pillow（Tkinter 与 Pygame图像互转）、pywin32（悬浮窗层级与透明）。

* 依赖安装：`pip install pygame pillow pywin32`

* 兼容性：优先 Windows；若缺失 pywin32，悬浮窗降级为 Tkinter 顶层透明窗。

## 目录结构（将创建）

* `main.py`：入口，应用初始化与路由

* `ui/`：Tkinter 页面

  * `login_view.py`、`register_view.py`、`recover_view.py`

  * `home_view.py`（主页）、`mall_view.py`（商城）

* `core/`

  * `account.py`：账号逻辑（注册/登录/找回）

  * `data_manager.py`：JSON 读写、缓存、原子更新、异步写队列

  * `runtime_tracker.py`：运行时间累计与同步

  * `pet.py`：桌宠模型、Pygame 动画接口、行为系统

  * `float_window.py`：悬浮窗（pywin32 + Tkinter），右键菜单/拖拽

  * `assets_loader.py`：像素资源加载与帧定义

* `assets/`：像素宠物帧图或像素矩阵（PNG/JSON）

* `data/`：`users.json`、`pets.json`（启动时自动创建模板）

* `README.md`：使用说明与依赖

## JSON 数据规范

* `data/users.json`

  * 键为用户名；值：`password(hash)`, `security_question`, `security_answer`, `unlocked_pets`, `total_run_time`, `pet_run_time`

* `data/pets.json`

  * 宠物字典：`price`, `description`, `pixel_size`（如 `32x32`），可选 `frames`（资源引用）

* 启动时若不存在自动初始化：默认宠物“像素小狗”，总运行时间 0。

## 账号系统设计

* 注册：唯一用户名校验、密码一致性、密保非空；密码以 `sha256` 存储。

* 登录：匹配用户名+hash 密码；支持“记住密码”（存入 `data/config.json`）。

* 找回：输入用户名后显示密保问题；答案正确方可重置密码。

* 错误提示与异常捕获：输入校验、文件读写异常、缺失字段默认值回填。

## 主页与路由

* 顶部：用户名、总运行时间（时:分:秒）。

* 中部：网格展示已解锁宠物（名称、像素预览、该宠物累计运行时间）。

* 底部：`选择为悬浮窗`、`进入商城`、`退出登录`。

* 选择宠物后启用按钮；所有时间每秒刷新（Tkinter `after`）。

## 商城模块

* 展示未解锁宠物列表：名称/预览/价格/描述。

* 购买前验证总运行时间 ≥ 价格；成功则扣减总运行时间，加入 `unlocked_pets`，写入 JSON。

* 失败显示“运行时间不足”。

## 桌宠与动画

* 宠物像素帧：统一 `32x32`（可扩展），支持呼吸/走动/眨眼基础动画，随机互动动作（摇尾/跳）。

* Pygame 渲染：在内存 Surface 逐帧合成；转换为 Tkinter 可显示的 `PhotoImage`（经 Pillow）。

* 行为系统：基于状态机（idle、walk、blink、interact），定时切换与随机事件。

## 悬浮窗实现（Windows 优先）

* 载体：Tkinter 顶层 `Toplevel` + `overrideredirect(True)`；窗口 `-topmost`。

* pywin32：通过 `HWND = toplevel.winfo_id()` 设置 `WS_EX_LAYERED | WS_EX_TOPMOST`，`SetLayeredWindowAttributes` 实现透明色与不规则形状。

* 拖拽：鼠标事件记录偏移，移动窗体；右键弹出菜单（返回主页、更换宠物、关闭悬浮窗）。

* 互动：左键点击触发随机动作与音效（可选）。

* 计时：悬浮窗开启后，每秒 +1 活跃宠物与总运行时间；关闭即停止。

## 运行时间累计与同步

* `RuntimeTracker` 持有当前用户名与活跃宠物；提供 `start() / stop()`。

* 每秒：更新内存计时与 UI，同步提交到 `data_manager` 写队列；失败重试。

* 扣减逻辑：商城购买会减总运行时间；避免负值，持久化后刷新 UI。

## 异步与性能

* JSON 写入：`DataManager` 维护 `Queue` 与守护线程，合并/去重键写（用户条目），批量每秒落盘；原子写 `*.tmp` + `replace`。

* UI 刷新：Tkinter `after(1000)` 驱动，无阻塞；Pygame 渲染在后台周期执行，产出帧交给 Tkinter 显示。

## 错误与异常处理

* 文件系统：不存在目录自动创建；写入失败记录到本地日志并重试。

* 资源与库加载：缺失资源使用占位帧；缺失 pywin32 时提示并降级。

* 输入校验：用户名/密码长度、非法字符；边界保护（时间下限 0）。

## 资源与像素素材

* 内置最小可运行资源：像素小狗 3–5 帧（PNG 或像素矩阵 JSON），小猫/兔子占位帧。

* 资源加载器支持：从 `assets/<pet>/` 读帧或从 `pets.json` 引用。

## 启动与入口

* `main.py` 初始化：创建数据目录与模板、加载 `pets.json`、启动 Tkinter 主循环。

* 函数级注释：所有公共函数/类均含中文注释，说明参数/返回值/异常。

* README：依赖安装、启动方式、常见问题与降级说明。

## 验证与测试计划

* 基本流程：注册→登录→主页展示→选择宠物→开启悬浮窗→计时累计→关闭悬浮窗→商城购买→解锁后在主页显示。

* 边界测试：重复用户名注册、错误密保答案、断电/异常写入原子性验证、无 pywin32 降级。

## 交付物清单

* 完整代码与模块文件、最小资源、`data` 模板、`README.md`。

* 可直接运行的 `main.py`，无明显 bug，满足需求。

## 后续扩展（可选）

* 扩展更多宠物与动作；增加音效与动态价格；多语言；系统托盘图标快捷操作。

